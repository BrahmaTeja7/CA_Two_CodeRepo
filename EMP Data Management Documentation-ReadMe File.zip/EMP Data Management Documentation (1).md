﻿**Employee Data Management App**

A simple and intuitive data management application for Employees.

**Table of Contents:**

General Info

Tools Used

Set Up

Status

**Introduction**:

Here is an Employee data management application with all the data related to an employee’s on boarding process until the end of their association in the organisation. This application collects, saves, organises, and maintains all the work related data and critical information about an employee. It has all the information right from employment details, access/privileges granted, status of an employee and their performance data. 

The real scope of this functionality is whenever an employee joins an organisation, all of the critical data pertaining to the employee needs to be present in a central location which can be accessed by the HR and other departments such as the finance department and the infrastructure team who keeps a track of them to process necessary actions. Hence, this application does help in for smooth processing and retention of employee data thereby saving both officials and employees time, and helps in updating it with as few steps as possible.

**Tools Used:** 

XAMPP Package

Apache Web Server

MySQL Database Server

PHP Scripting language

**Launch:**

First, we need to download XAMPP web server solution package ([XAMPP Download](https://www.apachefriends.org/download.html)) to host our employee data management application. Once downloaded, we need to install the XAMPP package and next we need to action on Apache Webserver and MySQL database server as shown below.

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.001.png)

Next, we have to click on Start to action on Apache and MySQL (shown below)

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.002.png)

Now, we need to create a database named as ITD. 

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.003.png)  

Once the database is created, we have to download the ITD.SQL file from GitHub and import it using phpMyAdmin. In order to do this, we have to click on Admin under MySQL in XAMPP as shown below.

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.004.png)

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.005.png)

Once the database structure is successfully imported, download the ITD.zip file from GitHub and extract the files. Once the extraction is complete, copy the ITD folder into the default location (C:\xampp\htdocs\).

Next step is to click on Action on Apache in XAMPP, it will redirect to the below screen, which shows that apache is working successfully.

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.006.png)

Our next step is to go to our local host ITD folder and check whether the system is working properly (localhost:81/itd/login.php)

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.007.jpeg)

Now, enter the below credentials in order to successfully login to the system.

User ID: root and password:  root

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.008.jpeg)


Here now, we can see all the records, employee details by clicking on employee data management in the home screen as below.

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.009.jpeg)


Now, under View all employees data, we can use other functionalities such as we can Add a new employee data as shown below

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.010.jpeg)


Similarly, under View all employees data, we can use other functionalities such as we can search for an employee data as shown below

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.011.jpeg)



Also, we can download an employee details using various filters as shown below

![](Aspose.Words.bbf15f45-63fb-49da-9cb7-bffb22481637.012.jpeg)


**Project Status:** 

All of the functionalities are tested and it is implemented successfully.

**Sources:**

Stack Overflow (<https://stackoverflow.com/>), Sourceforge (<https://sourceforge.net/projects/xampp/>), Apache friends (<https://www.phpmyadmin.net/>), W3Schools (<https://www.w3schools.com/>), GitHub (<https://github.com/>), MySQL.com (<https://www.mysql.com/>) and other websites



